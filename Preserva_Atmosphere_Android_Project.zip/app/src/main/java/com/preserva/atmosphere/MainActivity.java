package com.preserva.atmosphere;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText address;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showConnectScreen();
    }

    private void showConnectScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 24);
        root.setBackgroundColor(Color.rgb(241, 248, 255));

        TextView title = new TextView(this);
        title.setText("Preserva Atmosphere");
        title.setTextSize(27);
        title.setTextColor(Color.rgb(30, 64, 120));
        title.setPadding(0, 0, 0, 12);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Connect your phone to the same Wi-Fi as NodeMCU, or connect to the Preserva-CA hotspot. Enter the dashboard address shown in Arduino Serial Monitor.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setPadding(0, 0, 0, 20);
        root.addView(subtitle);

        address = new EditText(this);
        address.setSingleLine(true);
        address.setHint("http://192.168.4.1");
        address.setText("http://192.168.4.1");
        address.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI );
        root.addView(address);

        Button connect = new Button(this);
        connect.setText("Open Dashboard");
        root.addView(connect);
        connect.setOnClickListener(v -> {
            String url = address.getText().toString().trim();
            if (url.isEmpty()) url = "http://192.168.4.1";
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://" + url;
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
            openDashboard(url);
        });
        setContentView(root);
    }

    private void openDashboard(String url) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        Button changeAddress = new Button(this);
        changeAddress.setText("Change dashboard address");
        root.addView(changeAddress);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        changeAddress.setOnClickListener(v -> showConnectScreen());
        setContentView(root);
        webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
